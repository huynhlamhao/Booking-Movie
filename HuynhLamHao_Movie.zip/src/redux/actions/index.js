export const creactAction = (type, payLoad) => {
   return { type, payLoad };
};
